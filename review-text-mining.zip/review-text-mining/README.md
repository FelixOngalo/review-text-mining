# Customer Review Text Mining: Sentiment and Topic Modeling

**Question:** *(fill in)* Can a simple lexicon correctly classify review sentiment, and can unsupervised topic modeling (LDA) recover a review dataset's true topics with no topic labels given to it?

**Key findings:** *(fill in after running the analysis; lexicon sentiment accuracy, agreement with star rating, and LDA topic-recovery accuracy)*

**Tools:** R, tidytext, topicmodels, TF-IDF, lexicon-based sentiment analysis, LDA topic modeling, Quarto report

## Reproduce

1. `install.packages(c("tidyverse", "tidytext", "topicmodels", "scales"))`
2. Run in order:
   - `R/00_simulate_data.R` generates ~800 simulated reviews across 4 known topics with engineered sentiment skew
   - `R/01_clean.R` tokenizes the reviews and removes stopwords
   - `R/02_analyze.R` runs TF-IDF, lexicon sentiment scoring, and LDA topic modeling, then scores both against the ground truth
   - Render `reports/report.qmd` for the full written analysis

## Data

Simulated ~800 customer reviews across 4 topics (shipping, product quality, customer service, price), each built from its own small vocabulary pool with an engineered positive/negative sentiment skew, plus a star rating correlated with sentiment — all with known ground truth, so both methods below can be directly validated rather than just run.

## Method in brief

1. **TF-IDF** (using the true topic labels, as an EDA sanity check only) confirms the simulated vocabulary really is topic-distinctive before the unsupervised methods are asked to find it blind.
2. **Lexicon-based sentiment**: tokenize each review, match against a small built-in positive/negative word lexicon (included directly in code — no external download needed), classify by whichever count is higher. Validated against both the simulated true sentiment label and the independent star rating.
3. **LDA topic modeling**: an unsupervised generative model that infers a topic structure (documents as topic mixtures, topics as word distributions) purely from word co-occurrence, never given the true topic labels. Each document's dominant topic is then matched back to the closest true topic (since LDA's topic numbers are arbitrary) and scored for recovery accuracy.

## Key concepts

| Concept | What it means here |
|---|---|
| **Tokenization** | Splitting review text into individual words, with stopwords (the, and, was, ...) removed |
| **TF-IDF** | Scores a word high for a topic when it's frequent there but rare elsewhere — what makes a word genuinely distinctive, not just common |
| **Lexicon-based sentiment** | Classifying by counting matches against a known positive/negative word list — simple, but with no negation handling |
| **LDA (Latent Dirichlet Allocation)** | An unsupervised generative model: documents as mixtures of topics, topics as word distributions, inferred purely from word co-occurrence |
| **Topic-to-truth matching** | Since LDA's topic numbers are arbitrary, each must be matched to its closest true topic before "accuracy" is a meaningful concept |

## Project structure

```
R/00_simulate_data.R          generates reviews with known topics + sentiment skew
R/cleaning.R                  tokenization function
R/01_clean.R                  run tokenization, save tokens
R/text_mining_functions.R     built-in lexicon, sentiment scoring, LDA fitting, topic matching
R/02_analyze.R                run TF-IDF, sentiment, and LDA, score both against ground truth
reports/report.qmd            written analysis and charts
```

## Limitations

- The built-in lexicon has no negation handling and weighs every word equally.
- LDA's topic count (k=4) was set to match the known number of true topics; choosing k on real data (where it isn't known) is a separate modeling decision.
- Simulated reviews have deliberately clean, single-topic vocabulary; real reviews mix topics within one review far more often.
- *(add your own after running it on your own data)*
