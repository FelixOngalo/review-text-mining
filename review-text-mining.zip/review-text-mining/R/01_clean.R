library(readr)
library(dplyr)
source("R/cleaning.R")

reviews <- read_csv("data/raw/reviews.csv", show_col_types = FALSE)
tokens  <- tokenize_reviews(reviews)

cat("Reviews:          ", nrow(reviews), "\n")
cat("Tokens (post-stopword removal):", nrow(tokens), "\n")
cat("Unique words:     ", n_distinct(tokens$word), "\n")

saveRDS(reviews, "data/clean/reviews_clean.rds")
saveRDS(tokens,  "data/clean/tokens.rds")
