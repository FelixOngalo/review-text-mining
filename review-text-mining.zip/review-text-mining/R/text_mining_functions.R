# Reusable functions for lexicon-based sentiment scoring and LDA topic
# modeling on review text, using the tidytext + topicmodels ecosystem.

library(dplyr)
library(tidyr)
library(tidytext)
library(topicmodels)

#' A small, self-contained positive/negative word lexicon, in the same
#' (word, sentiment) shape as tidytext::get_sentiments("bing"). This is
#' included directly in code -- rather than calling get_sentiments(),
#' which downloads external lexicon data via the `textdata` package on
#' first use -- so this project runs fully offline and reproducibly with
#' no download step. It's a general-purpose review-sentiment word list,
#' not reverse-engineered from this project's own data generator, so
#' matching it against the simulated reviews is still a genuine test
#' (with realistic, imperfect recall) rather than a rigged one.
#'
#' @return A tibble: word, sentiment ("positive"/"negative").
built_in_lexicon <- function() {
  positive_words <- c(
    "excellent", "premium", "perfectly", "durable", "exceeded", "great",
    "helpful", "resolved", "friendly", "quick", "affordable", "reasonably",
    "good", "worth", "early", "fast", "well", "packaged", "fine", "happy",
    "love", "best", "awesome", "amazing", "nice", "pleased", "satisfied",
    "value", "recommend", "reliable", "sturdy", "efficient", "quality",
    "responsive", "pleasant", "smooth", "convenient"
  )
  negative_words <- c(
    "late", "slow", "damaged", "forever", "never", "broke", "cheap",
    "stopped", "poor", "fell", "apart", "rude", "weeks", "unhelpful",
    "overpriced", "expensive", "bad", "worst", "terrible", "awful",
    "disappointed", "disappointing", "broken", "faulty", "waste",
    "annoying", "frustrating", "unreliable", "flimsy", "defective",
    "complain", "complaint", "problem", "issue", "refund", "return"
  )
  bind_rows(
    tibble(word = positive_words, sentiment = "positive"),
    tibble(word = negative_words, sentiment = "negative")
  )
}

#' Score each review's sentiment by counting positive vs. negative
#' lexicon matches among its tokens, then classifying by which count is
#' higher. This is the simplest form of lexicon-based sentiment
#' analysis: no weighting, no negation handling (e.g. "not good" is
#' still counted as containing the positive word "good") -- a
#' deliberately simple baseline, whose limitations are worth seeing
#' directly rather than hidden by a more sophisticated method.
#'
#' Note: a review with ZERO lexicon matches on either side never
#' appears in the inner_join below, so it's simply absent from the
#' returned tibble rather than present with a score of 0 -- callers
#' that need every review represented (e.g. to compute accuracy against
#' true_sentiment for the whole dataset) should left_join this result
#' back onto the full review list and treat missing rows as "neutral,
#' no lexicon matches" (R/02_analyze.R does exactly this).
#'
#' @param tokens Tokenized reviews (one row per review_id/word), from
#'   tokenize_reviews().
#' @return A tibble: review_id, n_positive, n_negative, net_score,
#'   predicted_sentiment -- one row per review with at least one
#'   lexicon match.
score_sentiment_lexicon <- function(tokens) {
  lexicon <- built_in_lexicon()

  scored <- tokens |>
    inner_join(lexicon, by = "word") |>
    count(review_id, sentiment) |>
    pivot_wider(names_from = sentiment, values_from = n, values_fill = 0,
                names_prefix = "n_")

  # pivot_wider only creates a column for a sentiment value if it
  # appears at least once in the whole dataset -- guard against the
  # (unlikely, but possible on a tiny or unlucky dataset) case where
  # every lexicon match happened to be all-positive or all-negative,
  # which would otherwise leave the other column missing entirely and
  # make the mutate() below fail on an undefined column.
  if (!"n_positive" %in% names(scored)) scored$n_positive <- 0
  if (!"n_negative" %in% names(scored)) scored$n_negative <- 0

  scored |>
    mutate(
      net_score = n_positive - n_negative,
      predicted_sentiment = case_when(
        net_score > 0 ~ "positive",
        net_score < 0 ~ "negative",
        TRUE ~ "neutral"   # tied or no lexicon matches at all
      )
    )
}

#' Fit an LDA (Latent Dirichlet Allocation) topic model. LDA treats each
#' document as a MIXTURE of topics, and each topic as a distribution
#' over words -- fit by finding the topic structure that makes the
#' observed word co-occurrence patterns most probable. This is an
#' UNSUPERVISED method: the true_topic labels are never given to it,
#' which is exactly why recovering them afterward (see
#' match_lda_topics_to_truth()) is a meaningful validation, not a
#' circular one.
#'
#' @param tokens Tokenized reviews.
#' @param k Number of topics to fit.
#' @return A list: lda_fit (the raw topicmodels object), beta
#'   (topic-term probabilities, tidy format), gamma (document-topic
#'   probabilities, tidy format).
fit_lda_topics <- function(tokens, k = 4) {
  dtm <- tokens |>
    count(review_id, word) |>
    cast_dtm(review_id, word, n)

  lda_fit <- LDA(dtm, k = k, control = list(seed = 42))

  list(
    lda_fit = lda_fit,
    beta  = tidy(lda_fit, matrix = "beta"),
    gamma = tidy(lda_fit, matrix = "gamma")
  )
}

#' Match each fitted LDA topic number to the TRUE topic it best
#' corresponds to, then score how often the model's dominant-topic
#' assignment for a document agrees with that document's true topic.
#' This is a GREEDY matching (highest-overlap pairs claimed first) --
#' adequate for a small number of topics, though not guaranteed
#' globally optimal the way the Hungarian algorithm would be.
#'
#' @param gamma Tidy document-topic matrix from fit_lda_topics().
#' @param true_topics A tibble: review_id (as character), true_topic.
#' @return A list: topic_map (named vector, LDA topic -> true topic),
#'   accuracy (share of documents correctly matched), confusion
#'   (crosstab of assigned_true_topic vs. true_topic).
match_lda_topics_to_truth <- function(gamma, true_topics) {
  dominant_topic <- gamma |>
    group_by(document) |>
    slice_max(gamma, n = 1, with_ties = FALSE) |>
    ungroup() |>
    rename(review_id = document, lda_topic = topic) |>
    mutate(review_id = as.integer(review_id)) |>
    left_join(true_topics, by = "review_id")

  overlap <- dominant_topic |>
    count(lda_topic, true_topic) |>
    arrange(desc(n))

  # Greedily claim the highest-overlap (lda_topic, true_topic) pair,
  # then remove both from contention, repeating until every LDA topic
  # has a true-topic match.
  topic_map <- c()
  remaining <- overlap
  while (nrow(remaining) > 0 && length(topic_map) < n_distinct(overlap$lda_topic)) {
    best <- remaining |> slice_max(n, n = 1, with_ties = FALSE)
    topic_map[as.character(best$lda_topic)] <- best$true_topic
    remaining <- remaining |> filter(lda_topic != best$lda_topic, true_topic != best$true_topic)
  }

  dominant_topic <- dominant_topic |>
    mutate(assigned_true_topic = topic_map[as.character(lda_topic)])

  accuracy <- mean(dominant_topic$assigned_true_topic == dominant_topic$true_topic)
  confusion <- dominant_topic |> count(assigned_true_topic, true_topic)

  list(topic_map = topic_map, accuracy = accuracy, confusion = confusion, dominant_topic = dominant_topic)
}
