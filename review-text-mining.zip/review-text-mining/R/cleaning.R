library(dplyr)
library(tidytext)

# Tokenize review text into one row per (review_id, word), removing
# English stopwords (the, and, was, ...) via tidytext's built-in
# stop_words list -- these carry no topical or sentiment signal and
# would otherwise dominate word-frequency counts just by being common.
tokenize_reviews <- function(reviews) {
  reviews |>
    select(review_id, true_topic, true_sentiment, star_rating, review_text) |>
    unnest_tokens(word, review_text) |>
    anti_join(stop_words, by = "word")
}
