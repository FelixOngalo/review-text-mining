library(dplyr)
library(tidyr)
source("R/text_mining_functions.R")

reviews <- readRDS("data/clean/reviews_clean.rds")
tokens  <- readRDS("data/clean/tokens.rds")

cat("=== 1. TF-IDF: most distinctive words per TRUE topic ===\n")
# This uses the ground-truth topic labels purely as an EDA/sanity check
# -- confirming the simulated vocabulary is actually topic-distinctive
# -- before moving to the unsupervised methods below, which never see
# these labels.
tfidf_by_topic <- tokens |>
  count(true_topic, word) |>
  bind_tf_idf(word, true_topic, n) |>
  arrange(desc(tf_idf))

top_terms_per_topic <- tfidf_by_topic |>
  group_by(true_topic) |>
  slice_max(tf_idf, n = 8, with_ties = FALSE) |>
  ungroup()
print(top_terms_per_topic, n = 32)

cat("\n=== 2. Lexicon-based sentiment scoring ===\n")
sentiment_scores <- score_sentiment_lexicon(tokens)

# Left-join back onto every review so documents with zero lexicon
# matches are represented too (as "neutral"), per the function's note.
sentiment_full <- reviews |>
  select(review_id, true_sentiment, star_rating) |>
  left_join(sentiment_scores, by = "review_id") |>
  mutate(
    n_positive = replace_na(n_positive, 0),
    n_negative = replace_na(n_negative, 0),
    net_score  = replace_na(net_score, 0),
    predicted_sentiment = replace_na(predicted_sentiment, "neutral")
  )

sentiment_accuracy <- sentiment_full |>
  filter(predicted_sentiment != "neutral") |>   # neutral has no true-label equivalent to score against
  summarise(accuracy = mean(predicted_sentiment == true_sentiment), n = n())
cat("Lexicon sentiment accuracy (excluding neutral/no-match reviews):",
    round(sentiment_accuracy$accuracy, 4), "on", sentiment_accuracy$n, "reviews\n")
cat("Reviews with no lexicon match (classified neutral):",
    sum(sentiment_full$predicted_sentiment == "neutral"), "\n")

cat("\n=== 3. Does lexicon sentiment agree with star rating? ===\n")
# Star rating is an INDEPENDENT signal the lexicon method never sees --
# agreement here is a second, realistic validation check (the kind
# available on real review data, where "true_sentiment" as simulated
# here wouldn't actually exist).
star_check <- sentiment_full |>
  mutate(star_implies_positive = star_rating >= 4) |>
  filter(predicted_sentiment != "neutral") |>
  summarise(agreement_with_stars = mean((predicted_sentiment == "positive") == star_implies_positive))
print(star_check)

cat("\n=== 4. LDA topic modeling (unsupervised -- never sees true_topic) ===\n")
lda_result <- fit_lda_topics(tokens, k = 4)

top_terms_lda <- lda_result$beta |>
  group_by(topic) |>
  slice_max(beta, n = 8, with_ties = FALSE) |>
  ungroup()
print(top_terms_lda, n = 32)

cat("\n=== 5. Matching LDA topics back to ground truth ===\n")
true_topics <- reviews |> select(review_id, true_topic)
match_result <- match_lda_topics_to_truth(lda_result$gamma, true_topics)

cat("Topic map (LDA topic -> matched true topic):\n")
print(match_result$topic_map)
cat("\nTopic recovery accuracy:", round(match_result$accuracy, 4), "\n")
cat("\nConfusion matrix:\n")
print(match_result$confusion)

saveRDS(list(
  tfidf_by_topic = tfidf_by_topic,
  top_terms_per_topic = top_terms_per_topic,
  sentiment_full = sentiment_full,
  sentiment_accuracy = sentiment_accuracy,
  star_check = star_check,
  lda_result = lda_result,
  top_terms_lda = top_terms_lda,
  match_result = match_result
), "data/clean/analysis_results.rds")
