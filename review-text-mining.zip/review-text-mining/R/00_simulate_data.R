# Simulate ~800 customer reviews across 4 KNOWN topics, each with a
# built-in sentiment skew -- like market-basket-analysis and
# anomaly-detection-transactions elsewhere in this portfolio, the point
# of simulating with engineered ground truth is that it lets this
# project CONFIRM that topic modeling and sentiment analysis correctly
# recover a structure we already know is there, before trusting either
# method on data where the true topics/sentiment aren't known.
#
# Four topics, each built from its own small vocabulary pool so the
# topics are lexically distinguishable (which is what LDA actually
# detects -- co-occurring words, not "meaning"), and each topic has a
# different POSITIVE/NEGATIVE sentiment skew so sentiment analysis has
# genuine signal to find, not just noise.

library(dplyr)
library(tibble)
library(purrr)

set.seed(42)

topic_vocab <- list(
  shipping = list(
    positive = c("arrived early", "fast shipping", "well packaged", "quick delivery", "on time as promised"),
    negative = c("arrived late", "shipping was slow", "box was damaged", "delivery took forever", "tracking never updated")
  ),
  product_quality = list(
    positive = c("excellent build quality", "feels premium", "works perfectly", "very durable", "exceeded expectations"),
    negative = c("broke after a week", "feels cheap", "stopped working", "poor build quality", "fell apart quickly")
  ),
  customer_service = list(
    positive = c("support team was helpful", "resolved my issue fast", "friendly representative", "great customer service", "quick response to my email"),
    negative = c("support never responded", "rude representative", "took weeks to resolve", "unhelpful customer service", "had to call three times")
  ),
  price = list(
    positive = c("great value for the price", "worth every penny", "affordable and good", "reasonably priced", "good deal overall"),
    negative = c("way overpriced", "not worth the money", "too expensive for what it is", "poor value", "cheaper elsewhere")
  )
)

# Each topic's underlying sentiment skew -- e.g. shipping complaints are
# common (skewed negative), while price reviews skew positive (people who
# felt they got a good deal are more likely to mention price at all).
topic_sentiment_skew <- c(shipping = 0.4, product_quality = 0.55, customer_service = 0.45, price = 0.65)  # P(positive)

filler_phrases <- c("Ordered this last month.", "Using it daily now.", "Bought it for a gift.",
                     "Second one I've purchased.", "Would consider buying again.", "Not sure yet.")

n_reviews <- 800

reviews <- map_dfr(seq_len(n_reviews), function(i) {
  topic <- sample(names(topic_vocab), 1)
  is_positive <- runif(1) < topic_sentiment_skew[[topic]]
  phrase_pool <- if (is_positive) topic_vocab[[topic]]$positive else topic_vocab[[topic]]$negative

  n_phrases <- sample(1:2, 1)
  phrases <- sample(phrase_pool, n_phrases)
  n_filler <- sample(0:2, 1)
  filler <- if (n_filler > 0) sample(filler_phrases, n_filler) else character(0)

  text <- paste(c(phrases, filler), collapse = ". ")
  text <- paste0(toupper(substr(text, 1, 1)), substr(text, 2, nchar(text)), ".")

  # Star rating correlated with true sentiment, with some noise -- stars
  # are a real, independently-observable signal this project can use to
  # VALIDATE the text-derived sentiment score against, the same way
  # earlier projects validated a method against an independent label.
  star_rating <- if (is_positive) sample(c(4, 5, 5, 5), 1) else sample(c(1, 1, 2, 3), 1)

  tibble(
    review_id = i,
    true_topic = topic,
    true_sentiment = if (is_positive) "positive" else "negative",
    star_rating = star_rating,
    review_text = text
  )
})

dir.create("data/raw", showWarnings = FALSE, recursive = TRUE)
readr::write_csv(reviews, "data/raw/reviews.csv")

cat("Simulated", nrow(reviews), "reviews across", length(topic_vocab), "topics\n")
cat(table(reviews$true_topic), "\n")
